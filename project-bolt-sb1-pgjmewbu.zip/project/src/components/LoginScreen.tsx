@@ .. @@
             {isLogin && (
               <div className="mt-4 p-3 bg-gray-800 rounded-lg">
                 <p className="text-xs text-gray-400 mb-2">Contas de demonstração:</p>
-                <p className="text-xs text-gray-300">Admin: califellipee@outlook.com / calil112233</p>
+                <p className="text-xs text-gray-300 mb-1">🔑 Admin Master: califellipee@outlook.com / calil112233</p>
                 <p className="text-xs text-gray-300">Demo: demo@example.com / demo123</p>
               </div>
             )}